/**
 * 产品详情核心js文件
*/
$(function () {
    //调用插件函数
    magnifier({
        magnifier : "#magnifier1",//最外层的大容器
        width : 340,//承载容器宽
        height : 470,//承载容器高
        zoom :  2//缩放比例
    })
})